package utility;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import pagefactory.LeavePage;
import pagefactory.LoginPage;
import pagefactory.MyInfoPage;


public class Pages {
	public static LoginPage loginpage; 
	public static MyInfoPage myinfopage;
	public static LeavePage leavepage;	

	public static void loadPages(WebDriver driver) {
		loginpage=PageFactory.initElements(driver,LoginPage.class );
		myinfopage=PageFactory.initElements(driver, MyInfoPage.class );
		leavepage=PageFactory.initElements(driver,LeavePage.class );	
	}
}


