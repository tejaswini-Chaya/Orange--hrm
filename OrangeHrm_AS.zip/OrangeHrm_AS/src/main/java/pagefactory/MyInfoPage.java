package pagefactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class MyInfoPage {
	// declaration and inlization
		@FindBy(xpath="//span[text()='My Info']")
		private WebElement Myinfo;
   //getter and setters
		public WebElement getMyinfo() {
			return Myinfo;
		}

		public void setMyinfo(WebElement myinfo) {
			Myinfo = myinfo;
		}
		
		//logic
		
		public void cilckonMyinfo() {
			Myinfo.click();
		}
		
		
		
		
		
		
		
		
		
		

}
