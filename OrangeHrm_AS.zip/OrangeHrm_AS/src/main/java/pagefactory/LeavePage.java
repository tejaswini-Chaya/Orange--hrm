package pagefactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LeavePage {
	// declaration and inlization
	
		@FindBy(xpath = "//span[text()='Leave']")
		private WebElement cilckLeaveModule;
		
		@FindBy(xpath="//a[text()='Apply']")
		private WebElement cilckApplymodule;
		
		@FindBy(xpath="//i[@class='oxd-icon bi-caret-down-fill oxd-select-text--arrow']")
		private WebElement cilckoniconbtn;
		
		@FindBy(xpath="//div[text()='CAN - FMLA']")
		private WebElement Leavetype;
		
		@FindBy(xpath="//button[text()=' Apply ']")
		private WebElement Applybtn;

		
		//provide getters and setters
		public WebElement getCilckLeaveModule() {
			return cilckLeaveModule;
		}

		public void setCilckLeaveModule(WebElement cilckLeaveModule) {
			this.cilckLeaveModule = cilckLeaveModule;
		}

		public WebElement getCilckApplymodule() {
			return cilckApplymodule;
		}

		public void setCilckApplymodule(WebElement cilckApplymodule) {
			this.cilckApplymodule = cilckApplymodule;
		}

		public WebElement getCilckoniconbtn() {
			return cilckoniconbtn;
		}

		public void setCilckoniconbtn(WebElement cilckoniconbtn) {
			this.cilckoniconbtn = cilckoniconbtn;
		}

		public WebElement getLeavetype() {
			return Leavetype;
		}

		public void setLeavetype(WebElement leavetype) {
			Leavetype = leavetype;
		}

		public WebElement getApplybtn() {
			return Applybtn;
		}

		public void setApplybtn(WebElement applybtn) {
			Applybtn = applybtn;
		}
		//logic
		
		public void cilckLeaveModule ()
		{
			cilckLeaveModule.click();
		} 
		
		public void Applybtn ()
		{
			Applybtn.click();
		}
}
		
				
		
