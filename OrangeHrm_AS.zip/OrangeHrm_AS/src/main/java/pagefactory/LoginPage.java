package pagefactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class LoginPage {
	// declaration and inlization
	@FindBy(name = "username")
	private WebElement userNameEdt;
	
	@FindBy(name = "password")
	private WebElement passwordEdt;
	
	@FindBy(xpath = "//button[@type='submit']")
	private WebElement loginBtn;
	
	//provide getter method for private web elements
	
		public WebElement getUserNameEdt() {
			return userNameEdt;
		}
		public WebElement getPasswordEdt() {
			return passwordEdt;
		}
		public WebElement getSubmitBtn() {
			return loginBtn;
		}
		//Provide business Logic
		
		public void loginToApp(String username, String password)
		{
			userNameEdt.sendKeys(username);
			passwordEdt.sendKeys(password);
			
		}
		
		public void clickOnLoginButton()
		{
			loginBtn.click();
		}

}
