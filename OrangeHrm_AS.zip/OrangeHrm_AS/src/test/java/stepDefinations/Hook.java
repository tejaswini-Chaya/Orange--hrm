package stepDefinations;

import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.github.bonigarcia.wdm.WebDriverManager;
import utility.Base;
import utility.Pages;
import utility.PropertyFileUtility;
import utility.WebDriverUtility;

public class Hook extends WebDriverUtility{
	
	private Base base;
	
	public Hook(Base base) {
		this.base=base;
	}
	
	@Before
	public void beforeScenario() throws IOException
	{
		String browser = PropertyFileUtility.getPropertyValue("browser");
		if(browser.equalsIgnoreCase("chrome"))
		{
			WebDriverManager.chromedriver().setup();
			base.driver = new ChromeDriver();
			
		}
		else if(browser.equalsIgnoreCase("firefox"))
		{
			WebDriverManager.firefoxdriver().setup();
			base.driver = new FirefoxDriver();
		}
		else
		{
			System.out.println("invalid browser name");
		}
		
		base.driver.manage().window().maximize();
		base.driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		Pages.loadPages(base.driver);
	}

@After
	public void afterScenario(Scenario scenario) throws Throwable
	{
		if(scenario.isFailed())
		{
			
		    TakesScreenshot ts =(TakesScreenshot) base.driver;
		    byte[] src = ts.getScreenshotAs(OutputType.BYTES);
//			File targetfile = new File(System.getProperty("user.dir")+"\\Screenshots\\fullpage.png");
//			sourcefile.renameTo(targetfile);
			
		    byte[] screenshot = ts.getScreenshotAs(OutputType.BYTES);
		    scenario.attach(screenshot, "image/png", scenario.getName()); 
		
			getScreenShot(base.driver, scenario.getName());
			}
		base.driver.close();

}
}
