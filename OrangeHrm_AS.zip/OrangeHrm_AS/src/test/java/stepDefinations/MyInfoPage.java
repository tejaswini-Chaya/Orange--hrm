package stepDefinations;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class MyInfoPage {
	WebDriver driver;
	@Given("launch browser")
	public void launch_browser() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}

	@Given("entering the URL")
	public void entering_the_url() {
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	}

	@When("Login page is displayed then enter the username and password")
	public void login_page_is_displayed_then_enter_the_username_and_password() {
		driver.findElement(By.name("username")).sendKeys("Admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
	    
	}

	@When("click on the  Loginbutton and click on the Myinfopagemodule")
	public void click_on_the_loginbutton_and_click_on_the_myinfopagemodule() {
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		driver.findElement(By.xpath("//span[text()='My Info']")).click();
	}

	@Then("validating the Myinfo page is displayed or not")
	public void validating_the_myinfo_page_is_displayed_or_not() {
		String expTitle = "opensource-demo.orangehrmlive.com/web/index.php/pim/viewPersonalDetails/empNumber/7";
		String actTitle = driver.getTitle();
		Assert.assertEquals(actTitle, expTitle);
	    driver.close();
		}
	
//2ndscenario
	@Given("launching the browser")
	public void launching_the_browser() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}

	@Given("I will entering the URL")
	public void i_will_entering_the_url() {
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	}

	@When("Login page is displayed enter invalid credentials")
	public void login_page_is_displayed_enter_invalid_credentials() {
		driver.findElement(By.name("username")).sendKeys("Admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
	}

	@When("I can click on Login button then click the myinfopagemodule")
	public void i_can_click_on_login_button_then_click_the_myinfopagemodule() {
		driver.findElement(By.xpath("//div[@class='oxd-form-actions orangehrm-login-action']/descendant::button[text()=' Login ']")).click();
		driver.findElement(By.xpath("//span[text()='My Info']")).click();
	}
	@Then("to check the  error message is displayed or not")
	public void to_check_the_error_message_is_displayed_or_not() {
		String errMsg = driver.findElement(By.xpath("//div[@class='oxd-alert oxd-alert--error']")).getText().trim();
		Assert.assertEquals(errMsg, "You must specify a valid username and password.");
		driver.close();
	}
}




