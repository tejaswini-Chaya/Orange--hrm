package stepDefinations;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LoginPage {
	WebDriver driver;
	
	@Given("I will launch browser")
	public void i_will_launch_browser() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}
	

	@Given("enter the URL")
	public void enter_the_url() {
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	}

	@When("Login page is displayed i will enter username and password")
	public void login_page_is_displayed_i_will_enter_username_and_password() {
		driver.findElement(By.name("username")).sendKeys("Admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
	    	}

	@When("I will click on Login")
	public void i_will_click_on_login() {
		driver.findElement(By.xpath("//div[@class='oxd-form-actions orangehrm-login-action']/descendant::button[text()=' Login ']")).click();
	}

	@Then("I will validate wheather home page is displayed or not")
	public void i_will_validate_wheather_home_page_is_displayed_or_not() {
	String expTitle = "opensource-demo.orangehrmlive.com/web/index.php/dashboard/index";
	String actTitle = driver.getTitle();
	Assert.assertEquals(actTitle, expTitle);
    driver.close();
	}
//2ndscenario
	@Given("I can launch browser")
	public void i_can_launch_browser() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}

	@Given("I will enter the URL")
	public void i_will_enter_the_url() {
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	}

    @When("Login page is displayed enter invalid username and password")
	public void login_page_is_displayed_enter_invalid_username_and_password() {
		driver.findElement(By.name("username")).sendKeys("admin1");
		driver.findElement(By.name("password")).sendKeys("admin21");
	}

	@Then("Validate for error message is displayed or not")
	public void validate_for_error_message_is_displayed_or_not() {
		String errMsg = driver.findElement(By.xpath("//div[@class='oxd-alert oxd-alert--error']")).getText().trim();
		Assert.assertEquals(errMsg, "You must specify a valid username and password.");
		driver.close();
	}
}
