package stepDefinations;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LeavePage {
	WebDriver driver;
	
	@Given("user launch the browser")
	public void user_launch_the_browser() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}

	@Given("user enter the URL")
	public void user_enter_the_url() {
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	}

	@When("Login page is displayed user enter username and password")
	public void login_page_is_displayed_user_enter_username_and_password() {
		driver.findElement(By.name("username")).sendKeys("Admin");
		driver.findElement(By.name("password")).sendKeys("admin123");
	}

	@When("I will click on login button login")
	public void i_will_click_on_login_button_login() {
		driver.findElement(By.xpath("//div[@class='oxd-form-actions orangehrm-login-action']/descendant::button[text()=' Login ']")).click();
	}

	@When("click on the leave i will apply the leave in the leave page")
	public void click_on_the_leave_i_will_apply_the_leave_in_the_leave_page() {
		driver.findElement(By.xpath("//span[text()='Leave']")).click();
		driver.findElement(By.xpath("//a[text()='Apply']")).click();
		driver.findElement(By.xpath("//i[@class='oxd-icon bi-caret-down-fill oxd-select-text--arrow']")).click();
		driver.findElement(By.xpath("//div[text()='CAN - FMLA']")).click();
		driver.findElement(By.xpath("//input[@placeholder='yyyy-dd-mm']")).sendKeys("2024-12-07");
		driver.findElement(By.xpath("//input[@placeholder='yyyy-dd-mm']")).sendKeys("2024-16-07");
		driver.findElement(By.xpath(" //button[text()=' Apply ']")).click();
	}
@Then("validate the  leave page is displayed or not")
	public void validate_the_leave_page_is_displayed_or_not() {
			String expTitle = "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveList";
			String actTitle = driver.getTitle();
			Assert.assertEquals(actTitle, expTitle);
		    driver.close();
 }

@Given("I_will_ launch_browser")
public void i_will_launch_browser() {
	WebDriverManager.chromedriver().setup();
	driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
}
@Given("I_will_ enter_the_URL")

	public void i_will_enter_the_url() {
	driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
}

@When("I will enter the crendentials")
public void i_will_enter_the_crendentials() {
	driver.findElement(By.name("username")).sendKeys("Admin");
	driver.findElement(By.name("password")).sendKeys("admin123");
	
}
@When("I will click on the login")
public void i_will_click_on_the_login() {
	driver.findElement(By.xpath("//div[@class='oxd-form-actions orangehrm-login-action']/descendant::button[text()=' Login ']")).click();
	}

@When("I will click on the leave apply the leave with invalid date formate")
public void i_will_click_on_the_leave_apply_the_leave_with_invalid_date_formate() {
	driver.findElement(By.xpath("//span[text()='Leave']")).click();
	driver.findElement(By.xpath("//a[text()='Apply']")).click();
	driver.findElement(By.xpath("//i[@class='oxd-icon bi-caret-down-fill oxd-select-text--arrow']")).click();
	driver.findElement(By.xpath("//div[text()='CAN - FMLA']")).click();
	driver.findElement(By.xpath("//input[@placeholder='yyyy-dd-mm']")).sendKeys("07-12-2024");
	driver.findElement(By.xpath("//input[@placeholder='yyyy-dd-mm']")).sendKeys("07-16-2024");
	driver.findElement(By.xpath(" //button[text()=' Apply ']")).click();
   }

@Then("validate the leave page is displayed or not check the error message in leave page")
public void validate_the_leave_page_is_displayed_or_not_check_the_error_message_in_leave_page() {
	
	WebElement errMsg = driver.findElement(By.xpath("//span[@class='oxd-text oxd-text--span oxd-input-field-error-message oxd-input-group__message']"));
	Assert.assertEquals(errMsg, "You must specify a valid date formate.");
	driver.close();
}


}



	
	
	
	
//	@Given("browser page will launch")
//	public void browser_page_will_launch() {
//		WebDriverManager.chromedriver().setup();
//		driver = new ChromeDriver();
//		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
//	 }
//
//	@Given("URL is entering")
//	public void url_is_entering() {
//		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
//	 }

//	@When("enter the username and password loginpage is displayed")
//	public void enter_the_username_and_password_loginpage_is_displayed() {
//		driver.findElement(By.name("username")).sendKeys("Admin");
//		driver.findElement(By.name("password")).sendKeys("admin123");
//	}
//	@When("click on the Login button and login page is displayed")
//	public void click_on_the_login_button_and_login_page_is_displayed() {
//		driver.findElement(By.xpath("//div[@class='oxd-form-actions orangehrm-login-action']/descendant::button[text()=' Login ']")).click();
//	    }
//	@When("click on the leave module and apply the leave in the leave page")
//	public void click_on_the_leave_module_and_apply_the_leave_in_the_leave_page() {
//		driver.findElement(By.xpath("//span[text()='Leave']")).click();
//		driver.findElement(By.xpath("//a[text()='Apply']")).click();
//		driver.findElement(By.xpath("//i[@class='oxd-icon bi-caret-down-fill oxd-select-text--arrow']")).click();
//		driver.findElement(By.xpath("//div[text()='CAN - FMLA']")).click();
//		driver.findElement(By.xpath("//i[@class='oxd-icon bi-calendar oxd-date-input-icon']")).click();
		
		////input[@placeholder='yyyy-dd-mm']//text
		
		
//		driver.findElement(By.xpath("//button[@type='submit']")).click();
//		 }
//	@Then("validate the  leave page is displayed or not")
//	public void validate_the_leave_page_is_displayed_or_not() {
//		String expTitle = "https://opensource-demo.orangehrmlive.com/web/index.php/leave/viewLeaveList";
//		String actTitle = driver.getTitle();
//		Assert.assertEquals(actTitle, expTitle);
//	    driver.close();
//	}
//
//	@When("Login page is displayed and enter the credentials")
//	public void login_page_is_displayed_and_enter_the_credentials() {
//	    
//	}
//
//	
//
//	
//
//	
//
//	